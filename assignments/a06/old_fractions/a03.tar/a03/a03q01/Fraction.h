// file: Fraction.h
// name: Christian Elliott

//--------------------------------------------------------------------------
// Print fraction goes here (n and d)
//--------------------------------------------------------------------------
void fraction_print(int, int);

